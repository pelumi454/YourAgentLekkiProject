export const RouteLinks = {
  home: "/",
  login: "/login",
  signup: "/signup",
  logout: "/logout",
  setpassword: "/set-password",
  inputValue: "/optimization-calculator-form",
    result: "/optimization-calculator",
};
