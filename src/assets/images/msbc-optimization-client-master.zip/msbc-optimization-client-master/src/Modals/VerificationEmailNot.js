

export const VerificationEmailNot = () =>{
    return (

        <div className="Verification-modal__content">
            <p>We just sent to you a verification mail.</p>
            <p>
                Kindly check your mailbox to verify your email address and set up your
                account.
            </p>
        </div>
    );
};
